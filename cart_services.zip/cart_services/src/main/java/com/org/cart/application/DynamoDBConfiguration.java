package com.org.cart.application;

public class DynamoDBConfiguration {

	public static final String CART_TABLE_NAME = "cart";

    public static final String CART_ACCESS_TABLE_NAME = "cartaccess";

    public static final int SCAN_LIMIT = 50;


}

