package com.org.cart.router;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.org.cart.router.RequestRouter;

public class RequestRouterTest {

	private RequestRouter requestRouter;

	@Before
	public void setUp() throws Exception {

		requestRouter = new RequestRouter();

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {

	}

}
